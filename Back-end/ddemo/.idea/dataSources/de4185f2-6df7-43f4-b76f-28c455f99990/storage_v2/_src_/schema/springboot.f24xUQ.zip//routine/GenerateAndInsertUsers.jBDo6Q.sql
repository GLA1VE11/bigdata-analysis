create
    definer = root@localhost procedure GenerateAndInsertUsers()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE newName VARCHAR(255);
    DECLARE currentTimeStamp VARCHAR(20);
    DECLARE randomSuffix INT;
    DECLARE userCount INT;
    
    WHILE i <= 400 DO
        -- 生成新用户名
        SET currentTimeStamp = UNIX_TIMESTAMP();
        SET randomSuffix = FLOOR(RAND() * 1000000);
        SET newName = CONCAT('User_', currentTimeStamp, '_', randomSuffix);

        -- 检查用户名是否已存在
        SELECT COUNT(*) INTO userCount FROM mars_tianchi_user WHERE username = newName;
        IF userCount = 0 THEN
            -- 插入新用户
            INSERT INTO mars_tianchi_user (username, password) VALUES (newName, '123456');
            SET i = i + 1;
        END IF;
    END WHILE;
END;

